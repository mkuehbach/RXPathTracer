#!/usr/bin/env zsh

#BSUB -J RXPATHTRACER
#BSUB -o RXPATHTRACER.%J
###BSUB -e RXPATHTRACER.e%J
#BSUB -W 2:00
#BSUB -M 22000
#BSUB -a openmpi
#BSUB -n 100
#BSUB -x
#BSUB -m mpi-s
###BSUB -R "select[hpcwork]"
#BSUB -P jara0076

###mkdir -p runs/1095011000
###mv SCORE.Input.1095011000.uds runs/1095011000
###cd runs/1095011000

$MPIEXEC $FLAGS_MPI_BATCH rxpathtracer_gccOPT2 RXPathTracer.Input.91002.uds 91002
